export interface GeospatialQuery {
  latitude: number;
  longitude: number;
  radiusKm: number;
}

export interface LocationPoint {
  latitude: number;
  longitude: number;
  name?: string;
}

export class GeospatialService {
  // Calculate distance between two points using Haversine formula
  static calculateDistance(
    lat1: number, lon1: number, 
    lat2: number, lon2: number
  ): number {
    const R = 6371; // Earth's radius in kilometers
    const dLat = this.toRadians(lat2 - lat1);
    const dLon = this.toRadians(lon2 - lon1);
    
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(this.toRadians(lat1)) * Math.cos(this.toRadians(lat2)) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  private static toRadians(degrees: number): number {
    return degrees * (Math.PI / 180);
  }

  // Check if a point is within a radius of another point
  static isWithinRadius(
    centerLat: number, centerLon: number,
    pointLat: number, pointLon: number,
    radiusKm: number
  ): boolean {
    const distance = this.calculateDistance(centerLat, centerLon, pointLat, pointLon);
    return distance <= radiusKm;
  }

  // Find the closest point from a list of points
  static findClosest(
    centerLat: number, centerLon: number,
    points: LocationPoint[]
  ): LocationPoint | null {
    if (points.length === 0) return null;

    let closest = points[0];
    let minDistance = this.calculateDistance(
      centerLat, centerLon,
      closest.latitude, closest.longitude
    );

    for (let i = 1; i < points.length; i++) {
      const distance = this.calculateDistance(
        centerLat, centerLon,
        points[i].latitude, points[i].longitude
      );

      if (distance < minDistance) {
        minDistance = distance;
        closest = points[i];
      }
    }

    return closest;
  }

  // Get a bounding box for a center point and radius
  static getBoundingBox(
    centerLat: number, centerLon: number, radiusKm: number
  ): {
    north: number;
    south: number;
    east: number;
    west: number;
  } {
    const latDelta = radiusKm / 111; // Approximate km per degree latitude
    const lonDelta = radiusKm / (111 * Math.cos(this.toRadians(centerLat)));

    return {
      north: centerLat + latDelta,
      south: centerLat - latDelta,
      east: centerLon + lonDelta,
      west: centerLon - lonDelta
    };
  }

  // Generate a search query for geospatial operations
  static createSearchQuery(
    centerLat: number, centerLon: number, radiusKm: number
  ): GeospatialQuery {
    return {
      latitude: centerLat,
      longitude: centerLon,
      radiusKm
    };
  }
}
