export interface GeminiResponse {
  location?: string;
  confidence?: number;
  isAuthentic?: boolean;
  analysis?: string;
}

export interface GeocodingResponse {
  latitude: number;
  longitude: number;
  formattedAddress: string;
}

export interface SocialMediaPost {
  id: string;
  user: string;
  content: string;
  timestamp: Date;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  type: 'need' | 'offer' | 'info' | 'alert';
}

export interface OfficialUpdate {
  id: string;
  source: string;
  title: string;
  content: string;
  timestamp: Date;
  url: string;
}

class MockApiService {
  // Mock Gemini API for location extraction
  async extractLocationFromText(text: string): Promise<GeminiResponse> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));

    // Simple pattern matching for location extraction
    const locationPatterns = [
      /(?:in|at|near)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*(?:,\s*[A-Z]{2})?)/gi,
      /([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*,\s*[A-Z]{2})/g,
      /(Manhattan|Brooklyn|Queens|Bronx|Staten Island)/gi,
      /(NYC|New York City|Los Angeles|San Francisco|Miami|Chicago|Houston)/gi
    ];

    for (const pattern of locationPatterns) {
      const match = text.match(pattern);
      if (match) {
        return {
          location: match[0].replace(/^(?:in|at|near)\s+/i, '').trim(),
          confidence: 0.85
        };
      }
    }

    return { confidence: 0.0 };
  }

  // Mock Gemini API for image verification
  async verifyImage(imageUrl: string): Promise<GeminiResponse> {
    await new Promise(resolve => setTimeout(resolve, 800));

    // Mock verification logic based on URL or random
    const isFloodImage = imageUrl.includes('flood') || imageUrl.includes('water');
    const isFireImage = imageUrl.includes('fire') || imageUrl.includes('smoke');
    
    const authenticity = Math.random() > 0.2; // 80% chance of being authentic
    
    let analysis = "Image analysis complete. ";
    if (isFloodImage) {
      analysis += "Detected water damage consistent with flooding. ";
    } else if (isFireImage) {
      analysis += "Detected fire damage and smoke patterns. ";
    } else {
      analysis += "General disaster-related imagery detected. ";
    }
    
    analysis += authenticity ? "No signs of manipulation detected." : "Potential signs of digital manipulation detected.";

    return {
      isAuthentic: authenticity,
      analysis,
      confidence: 0.75 + Math.random() * 0.2
    };
  }

  // Mock geocoding service
  async geocodeLocation(locationName: string): Promise<GeocodingResponse | null> {
    await new Promise(resolve => setTimeout(resolve, 300));

    // Mock coordinate mapping for common locations
    const mockCoordinates: Record<string, { lat: number; lng: number }> = {
      'manhattan, nyc': { lat: 40.7831, lng: -73.9712 },
      'manhattan': { lat: 40.7831, lng: -73.9712 },
      'brooklyn, nyc': { lat: 40.6782, lng: -73.9442 },
      'los angeles, ca': { lat: 34.0522, lng: -118.2437 },
      'san francisco, ca': { lat: 37.7749, lng: -122.4194 },
      'chicago, il': { lat: 41.8781, lng: -87.6298 },
      'miami, fl': { lat: 25.7617, lng: -80.1918 },
      'lower east side, nyc': { lat: 40.7154, lng: -73.9843 },
      'wall street, nyc': { lat: 40.7074, lng: -73.9776 },
      'central park, nyc': { lat: 40.7829, lng: -73.9654 }
    };

    const key = locationName.toLowerCase();
    const coords = mockCoordinates[key];
    
    if (coords) {
      return {
        latitude: coords.lat,
        longitude: coords.lng,
        formattedAddress: locationName
      };
    }

    // Generate random coordinates within reasonable bounds for unknown locations
    const lat = 40.7128 + (Math.random() - 0.5) * 0.2; // Around NYC
    const lng = -74.0060 + (Math.random() - 0.5) * 0.2;
    
    return {
      latitude: lat,
      longitude: lng,
      formattedAddress: locationName
    };
  }

  // Mock social media API
  async fetchSocialMediaReports(keywords: string[] = ['disaster', 'emergency', 'help']): Promise<SocialMediaPost[]> {
    await new Promise(resolve => setTimeout(resolve, 400));

    const mockPosts: SocialMediaPost[] = [
      {
        id: '1',
        user: '@citizen_nyc',
        content: '#floodrelief Need emergency food supplies in Lower East Side. Water level rising fast! #NYCFlood',
        timestamp: new Date(Date.now() - 2 * 60 * 1000),
        priority: 'urgent',
        type: 'need'
      },
      {
        id: '2',
        user: '@relief_volunteer',
        content: 'We have 20 emergency blankets available for distribution in Manhattan. Contact us for pickup location. #DisasterRelief',
        timestamp: new Date(Date.now() - 5 * 60 * 1000),
        priority: 'medium',
        type: 'offer'
      },
      {
        id: '3',
        user: '@weather_updates',
        content: 'OFFICIAL: Flash flood warning extended until 6 PM. Avoid subway stations in lower Manhattan. Updates: bit.ly/nyc-flood-info',
        timestamp: new Date(Date.now() - 8 * 60 * 1000),
        priority: 'high',
        type: 'info'
      },
      {
        id: '4',
        user: '@emergency_sos',
        content: 'URGENT: Trapped in basement apartment on Delancey St. Water rising. Need immediate rescue! #SOS #NYCFlood',
        timestamp: new Date(Date.now() - 1 * 60 * 1000),
        priority: 'urgent',
        type: 'alert'
      },
      {
        id: '5',
        user: '@red_cross_ny',
        content: 'Emergency shelter now open at Manhattan Community Center. Capacity for 150 people. Medical support available. #EmergencyShelter',
        timestamp: new Date(Date.now() - 12 * 60 * 1000),
        priority: 'medium',
        type: 'info'
      }
    ];

    // Return posts sorted by timestamp, newest first
    return mockPosts.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  // Mock official updates scraper
  async fetchOfficialUpdates(sources: string[] = ['fema', 'redcross']): Promise<OfficialUpdate[]> {
    await new Promise(resolve => setTimeout(resolve, 600));

    const mockUpdates: OfficialUpdate[] = [
      {
        id: '1',
        source: 'FEMA',
        title: 'Federal Emergency Declaration for NYC Flooding',
        content: 'FEMA has declared a federal emergency for New York City due to unprecedented flooding. Federal aid is being mobilized to support local response efforts.',
        timestamp: new Date(Date.now() - 30 * 60 * 1000),
        url: 'https://fema.gov/disaster/nyc-flood-2024'
      },
      {
        id: '2',
        source: 'Red Cross',
        title: 'Emergency Shelter Operations Update',
        content: 'Red Cross has opened 5 emergency shelters across Manhattan and Brooklyn. Total capacity: 750 people. Volunteers needed for operations.',
        timestamp: new Date(Date.now() - 45 * 60 * 1000),
        url: 'https://redcross.org/nyc-flood-response'
      },
      {
        id: '3',
        source: 'NYC Emergency Management',
        title: 'Travel Advisory: Subway System Disruptions',
        content: 'Multiple subway lines suspended due to flooding. Use alternative transportation. Real-time updates available on MTA website.',
        timestamp: new Date(Date.now() - 20 * 60 * 1000),
        url: 'https://nyc.gov/emergency-travel-advisory'
      }
    ];

    return mockUpdates.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }
}

export const mockApiService = new MockApiService();
