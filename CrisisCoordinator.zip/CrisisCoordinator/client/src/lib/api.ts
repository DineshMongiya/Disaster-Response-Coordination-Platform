import { apiRequest } from './queryClient';

export interface DisasterFilters {
  tag?: string;
  owner?: string;
}

export interface GeocodeRequest {
  text?: string;
  locationName?: string;
}

export interface VerifyImageRequest {
  imageUrl: string;
  reportId?: number;
}

export interface ResourceQuery {
  lat?: number;
  lon?: number;
  radius?: number;
}

export class ApiClient {
  // Disasters
  static async getDisasters(filters?: DisasterFilters) {
    const params = new URLSearchParams();
    if (filters?.tag) params.append('tag', filters.tag);
    if (filters?.owner) params.append('owner', filters.owner);
    
    const url = `/api/disasters${params.toString() ? `?${params.toString()}` : ''}`;
    const response = await apiRequest('GET', url);
    return response.json();
  }

  static async getDisaster(id: number) {
    const response = await apiRequest('GET', `/api/disasters/${id}`);
    return response.json();
  }

  static async createDisaster(data: any) {
    const response = await apiRequest('POST', '/api/disasters', data);
    return response.json();
  }

  static async updateDisaster(id: number, data: any) {
    const response = await apiRequest('PUT', `/api/disasters/${id}`, data);
    return response.json();
  }

  static async deleteDisaster(id: number) {
    await apiRequest('DELETE', `/api/disasters/${id}`);
  }

  // Social Media
  static async getSocialMediaReports(disasterId: number) {
    const response = await apiRequest('GET', `/api/disasters/${disasterId}/social-media`);
    return response.json();
  }

  // Resources
  static async getResources(disasterId: number, query?: ResourceQuery) {
    const params = new URLSearchParams();
    if (query?.lat !== undefined) params.append('lat', query.lat.toString());
    if (query?.lon !== undefined) params.append('lon', query.lon.toString());
    if (query?.radius !== undefined) params.append('radius', query.radius.toString());
    
    const url = `/api/disasters/${disasterId}/resources${params.toString() ? `?${params.toString()}` : ''}`;
    const response = await apiRequest('GET', url);
    return response.json();
  }

  static async createResource(data: any) {
    const response = await apiRequest('POST', '/api/resources', data);
    return response.json();
  }

  // Reports
  static async getReports(disasterId?: number) {
    const params = new URLSearchParams();
    if (disasterId) params.append('disasterId', disasterId.toString());
    
    const url = `/api/reports${params.toString() ? `?${params.toString()}` : ''}`;
    const response = await apiRequest('GET', url);
    return response.json();
  }

  static async createReport(data: any) {
    const response = await apiRequest('POST', '/api/reports', data);
    return response.json();
  }

  // Official Updates
  static async getOfficialUpdates(disasterId: number) {
    const response = await apiRequest('GET', `/api/disasters/${disasterId}/official-updates`);
    return response.json();
  }

  // Image Verification
  static async verifyImage(disasterId: number, data: VerifyImageRequest) {
    const response = await apiRequest('POST', `/api/disasters/${disasterId}/verify-image`, data);
    return response.json();
  }

  // Geocoding
  static async geocode(data: GeocodeRequest) {
    const response = await apiRequest('POST', '/api/geocode', data);
    return response.json();
  }

  // Stats
  static async getStats() {
    const response = await apiRequest('GET', '/api/stats');
    return response.json();
  }
}
