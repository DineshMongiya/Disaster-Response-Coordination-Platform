import { useState } from "react";
import Sidebar from "@/components/Sidebar";
import TopBar from "@/components/TopBar";
import StatsGrid from "@/components/StatsGrid";
import ActiveDisastersList from "@/components/ActiveDisastersList";
import SocialMediaFeed from "@/components/SocialMediaFeed";
import ResourceMap from "@/components/ResourceMap";
import RecentReports from "@/components/RecentReports";
import CreateDisasterModal from "@/components/CreateDisasterModal";
import { useWebSocket } from "@/hooks/useWebSocket";
import { useQuery } from "@tanstack/react-query";
import { ApiClient } from "@/lib/api";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { TriangleAlert } from "lucide-react";

export default function Dashboard() {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const { isConnected } = useWebSocket();

  const { data: disasters = [] } = useQuery({
    queryKey: ['/api/disasters'],
    queryFn: () => ApiClient.getDisasters(),
  });

  const { data: stats } = useQuery({
    queryKey: ['/api/stats'],
    queryFn: () => ApiClient.getStats(),
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  const urgentDisasters = disasters.filter((d: any) => 
    d.tags.includes('urgent') || d.tags.includes('emergency')
  );

  return (
    <div className="min-h-screen flex bg-background">
      <Sidebar />
      
      <main className="flex-1 ml-64 overflow-x-hidden">
        <TopBar onCreateDisaster={() => setShowCreateModal(true)} />
        
        <div className="p-6 space-y-6">
          {/* Alert Banner */}
          {urgentDisasters.length > 0 && (
            <Alert className="border-accent bg-accent/10">
              <TriangleAlert className="h-4 w-4 text-accent" />
              <AlertDescription className="text-accent">
                <span className="font-medium">High Priority Alert:</span> {urgentDisasters.length} active disasters require immediate attention. 
                Last updated: {stats?.lastUpdated ? new Date(stats.lastUpdated).toLocaleTimeString() : 'Unknown'}
              </AlertDescription>
            </Alert>
          )}

          <StatsGrid />

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <ActiveDisastersList />
            <SocialMediaFeed />
          </div>

          <ResourceMap />
          
          <RecentReports />
        </div>
      </main>

      <CreateDisasterModal 
        open={showCreateModal} 
        onOpenChange={setShowCreateModal}
      />
    </div>
  );
}
