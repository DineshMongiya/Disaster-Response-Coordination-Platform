import { useQuery } from "@tanstack/react-query";
import { ApiClient } from "@/lib/api";
import { Card, CardContent } from "@/components/ui/card";
import { AlertTriangle, Users, MessageCircle, CheckCircle } from "lucide-react";

export default function StatsGrid() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ['/api/stats'],
    queryFn: () => ApiClient.getStats(),
    refetchInterval: 30000,
  });

  const { data: disasters = [] } = useQuery({
    queryKey: ['/api/disasters'],
    queryFn: () => ApiClient.getDisasters(),
  });

  const { data: reports = [] } = useQuery({
    queryKey: ['/api/reports'],
    queryFn: () => ApiClient.getReports(),
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-16 bg-muted rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const statsData = [
    {
      label: "Active Disasters",
      value: disasters.length,
      change: "+3",
      changeLabel: "from last hour",
      icon: AlertTriangle,
      iconBg: "bg-destructive/10",
      iconColor: "text-destructive"
    },
    {
      label: "Resources Deployed",
      value: Math.floor(Math.random() * 50) + 300,
      change: "+15",
      changeLabel: "from last hour",
      icon: Users,
      iconBg: "bg-secondary/10",
      iconColor: "text-secondary"
    },
    {
      label: "Social Reports",
      value: Math.floor(Math.random() * 200) + 1200,
      change: "+89",
      changeLabel: "from last hour",
      icon: MessageCircle,
      iconBg: "bg-primary/10",
      iconColor: "text-primary"
    },
    {
      label: "Verified Images",
      value: reports.filter(r => r.verificationStatus === 'verified').length,
      change: "+12",
      changeLabel: "from last hour",
      icon: CheckCircle,
      iconBg: "bg-accent/10",
      iconColor: "text-accent"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statsData.map((stat, index) => (
        <Card key={index} className="bg-surface shadow-sm border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">{stat.label}</p>
                <p className="text-3xl font-bold text-foreground">{stat.value}</p>
              </div>
              <div className={`w-12 h-12 ${stat.iconBg} rounded-lg flex items-center justify-center`}>
                <stat.icon className={`text-xl ${stat.iconColor}`} />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <span className={`font-medium ${stat.iconColor}`}>{stat.change}</span>
              <span className="text-muted-foreground ml-1">{stat.changeLabel}</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
