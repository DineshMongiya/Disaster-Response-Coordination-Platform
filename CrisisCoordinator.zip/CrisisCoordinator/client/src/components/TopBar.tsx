import { Bell, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";

interface TopBarProps {
  onCreateDisaster: () => void;
}

export default function TopBar({ onCreateDisaster }: TopBarProps) {
  return (
    <header className="bg-surface shadow-sm border-b border-border px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Emergency Response Dashboard</h2>
          <p className="text-sm text-muted-foreground">Real-time disaster coordination and monitoring</p>
        </div>
        <div className="flex items-center space-x-4">
          {/* Notification Bell */}
          <button className="relative p-2 text-muted-foreground hover:text-foreground">
            <Bell className="h-5 w-5" />
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-destructive text-destructive-foreground text-xs rounded-full flex items-center justify-center">
              3
            </span>
          </button>
          
          {/* Create Disaster Button */}
          <Button 
            onClick={onCreateDisaster}
            className="bg-primary text-primary-foreground hover:bg-primary/90 font-medium"
          >
            <Plus className="h-4 w-4 mr-2" />
            New Disaster
          </Button>
        </div>
      </div>
    </header>
  );
}
