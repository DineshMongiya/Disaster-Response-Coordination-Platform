import { useQuery } from "@tanstack/react-query";
import { ApiClient } from "@/lib/api";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Minus } from "lucide-react";

export default function ResourceMap() {
  const { data: resources = [], isLoading } = useQuery({
    queryKey: ['/api/disasters', 1, 'resources'],
    queryFn: () => ApiClient.getResources(1),
  });

  const resourceTypes = [
    { label: 'Shelters', active: true, color: 'primary' },
    { label: 'Medical', active: false, color: 'secondary' },
    { label: 'Food', active: false, color: 'accent' },
  ];

  if (isLoading) {
    return (
      <Card className="bg-surface shadow-sm border-border">
        <CardHeader>
          <h3 className="text-lg font-semibold text-foreground">Resource Distribution Map</h3>
        </CardHeader>
        <CardContent className="p-6">
          <div className="w-full h-64 bg-muted rounded-lg animate-pulse"></div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-surface shadow-sm border-border">
      <CardHeader className="p-6 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-foreground">Resource Distribution Map</h3>
          <div className="flex items-center space-x-2">
            {resourceTypes.map((type) => (
              <Button
                key={type.label}
                variant={type.active ? "default" : "outline"}
                size="sm"
                className={type.active ? `bg-${type.color} text-${type.color}-foreground` : ''}
              >
                {type.label}
              </Button>
            ))}
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        {/* Mock Map Area */}
        <div className="w-full h-64 bg-gradient-to-br from-muted to-muted/50 rounded-lg relative overflow-hidden">
          {/* Mock location markers */}
          {[
            { top: '25%', left: '20%', color: 'destructive' },
            { top: '50%', left: '35%', color: 'secondary' },
            { top: '30%', right: '25%', color: 'primary' },
            { bottom: '30%', left: '20%', color: 'accent' },
            { bottom: '40%', right: '35%', color: 'secondary' },
          ].map((marker, index) => (
            <div
              key={index}
              className={`absolute w-4 h-4 bg-${marker.color} rounded-full border-2 border-white shadow-lg`}
              style={{
                top: marker.top,
                left: marker.left,
                right: marker.right,
                bottom: marker.bottom,
              }}
            ></div>
          ))}
          
          {/* Map controls */}
          <div className="absolute top-4 right-4 space-y-2">
            <Button size="sm" variant="outline" className="w-8 h-8 p-0 bg-white">
              <Plus className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="outline" className="w-8 h-8 p-0 bg-white">
              <Minus className="h-4 w-4" />
            </Button>
          </div>
          
          {/* Mock tooltip */}
          <div className="absolute top-12 left-16 bg-white rounded-lg shadow-lg p-3 border border-border transform -translate-x-1/2">
            <div className="text-xs font-medium text-foreground">Red Cross Shelter</div>
            <div className="text-xs text-muted-foreground">Manhattan Community Center</div>
            <div className="text-xs text-muted-foreground">Capacity: 150 people</div>
          </div>
        </div>
        
        {/* Map Legend */}
        <div className="mt-4 flex items-center justify-center space-x-6 text-sm">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-destructive rounded-full"></div>
            <span className="text-muted-foreground">Active Disasters</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-secondary rounded-full"></div>
            <span className="text-muted-foreground">Shelters</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-primary rounded-full"></div>
            <span className="text-muted-foreground">Medical Centers</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-accent rounded-full"></div>
            <span className="text-muted-foreground">Food Distribution</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
