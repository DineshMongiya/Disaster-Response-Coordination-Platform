import { useQuery } from "@tanstack/react-query";
import { ApiClient } from "@/lib/api";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useWebSocket } from "@/hooks/useWebSocket";
import { useEffect, useState } from "react";
import { queryClient } from "@/lib/queryClient";
import { User, Repeat, Heart } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function SocialMediaFeed() {
  const [selectedDisasterId, setSelectedDisasterId] = useState<number | null>(null);
  const { subscribe } = useWebSocket();

  const { data: disasters = [] } = useQuery({
    queryKey: ['/api/disasters'],
    queryFn: () => ApiClient.getDisasters(),
  });

  const { data: socialReports = [], isLoading } = useQuery({
    queryKey: ['/api/disasters', selectedDisasterId, 'social-media'],
    queryFn: () => ApiClient.getSocialMediaReports(selectedDisasterId),
    enabled: false, // Disabled to prevent excessive API calls
    refetchInterval: false,
    staleTime: Infinity,
  });

  useEffect(() => {
    // Set the first available disaster as selected
    if (disasters.length > 0 && !selectedDisasterId) {
      setSelectedDisasterId(disasters[0].id);
    }
  }, [disasters, selectedDisasterId]);

  useEffect(() => {
    const unsubscribe = subscribe('social_media_updated', (data) => {
      if (data.disasterId === selectedDisasterId) {
        queryClient.invalidateQueries({ 
          queryKey: ['/api/disasters', selectedDisasterId, 'social-media'] 
        });
      }
    });

    return unsubscribe;
  }, [subscribe, selectedDisasterId]);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'destructive';
      case 'high': return 'accent';
      case 'medium': return 'secondary';
      default: return 'outline';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'need': return 'destructive';
      case 'offer': return 'secondary';
      case 'alert': return 'destructive';
      default: return 'primary';
    }
  };

  if (isLoading) {
    return (
      <Card className="bg-surface shadow-sm border-border">
        <CardHeader>
          <h3 className="text-lg font-semibold text-foreground">Social Media Monitor</h3>
        </CardHeader>
        <CardContent className="p-6 space-y-4 max-h-96 overflow-y-auto">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="animate-pulse border-l-4 border-muted pl-4 py-2">
              <div className="h-4 bg-muted rounded mb-2"></div>
              <div className="h-16 bg-muted rounded"></div>
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-surface shadow-sm border-border">
      <CardHeader className="p-6 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-foreground">Social Media Monitor</h3>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-secondary rounded-full animate-pulse"></div>
            <span className="text-xs text-muted-foreground">Live</span>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6 space-y-4 max-h-96 overflow-y-auto">
        <div className="text-center py-8 text-muted-foreground">
          Social media monitoring temporarily disabled for performance optimization
        </div>
      </CardContent>
    </Card>
  );
}
