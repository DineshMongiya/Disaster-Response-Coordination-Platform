import { useQuery } from "@tanstack/react-query";
import { ApiClient } from "@/lib/api";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useWebSocket } from "@/hooks/useWebSocket";
import { useEffect } from "react";
import { queryClient } from "@/lib/queryClient";
import { Waves, Flame, Building, MoreVertical } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function ActiveDisastersList() {
  const { subscribe } = useWebSocket();

  const { data: disasters = [], isLoading } = useQuery({
    queryKey: ['/api/disasters'],
    queryFn: () => ApiClient.getDisasters(),
  });

  useEffect(() => {
    const unsubscribe = subscribe('disaster_created', () => {
      queryClient.invalidateQueries({ queryKey: ['/api/disasters'] });
    });

    const unsubscribeUpdate = subscribe('disaster_updated', () => {
      queryClient.invalidateQueries({ queryKey: ['/api/disasters'] });
    });

    return () => {
      unsubscribe();
      unsubscribeUpdate();
    };
  }, [subscribe]);

  const getDisasterIcon = (tags: string[]) => {
    if (tags.includes('flood')) return Waves;
    if (tags.includes('fire')) return Flame;
    if (tags.includes('earthquake')) return Building;
    return Building;
  };

  const getDisasterColor = (tags: string[]) => {
    if (tags.includes('urgent')) return 'destructive';
    if (tags.includes('fire')) return 'accent';
    if (tags.includes('flood')) return 'destructive';
    return 'secondary';
  };

  if (isLoading) {
    return (
      <Card className="bg-surface shadow-sm border-border">
        <CardHeader>
          <h3 className="text-lg font-semibold text-foreground">Active Disasters</h3>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="animate-pulse bg-muted rounded-lg p-4 h-20"></div>
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-surface shadow-sm border-border">
      <CardHeader className="p-6 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-foreground">Active Disasters</h3>
          <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80">
            View All
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-6 space-y-4">
        {disasters.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No active disasters reported
          </div>
        ) : (
          disasters.slice(0, 3).map((disaster: any) => {
            const IconComponent = getDisasterIcon(disaster.tags);
            const color = getDisasterColor(disaster.tags);
            
            return (
              <div key={disaster.id} className="flex items-start space-x-4 p-4 bg-muted rounded-lg">
                <div className={`w-10 h-10 bg-${color}/10 rounded-lg flex items-center justify-center flex-shrink-0`}>
                  <IconComponent className={`text-${color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-medium text-foreground">{disaster.title}</h4>
                  <p className="text-sm text-muted-foreground">{disaster.locationName}</p>
                  <div className="flex items-center mt-2 space-x-2">
                    {disaster.tags.map((tag: string) => (
                      <Badge key={tag} variant={tag === 'urgent' ? 'destructive' : 'secondary'} className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="flex-shrink-0 text-right">
                  <p className="text-xs text-muted-foreground">
                    {formatDistanceToNow(new Date(disaster.createdAt), { addSuffix: true })}
                  </p>
                  <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground mt-1">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            );
          })
        )}
      </CardContent>
    </Card>
  );
}
