import { useWebSocket } from "@/hooks/useWebSocket";
import { Shield, Gauge, AlertTriangle, MessageCircle, MapPin, FileText, CheckCircle, User } from "lucide-react";

export default function Sidebar() {
  const { isConnected, connectionStatus } = useWebSocket();

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Gauge, active: true },
    { id: 'disasters', label: 'Disasters', icon: AlertTriangle },
    { id: 'social-media', label: 'Social Monitor', icon: MessageCircle },
    { id: 'resources', label: 'Resources', icon: MapPin },
    { id: 'reports', label: 'Reports', icon: FileText },
    { id: 'verification', label: 'Verification', icon: CheckCircle },
  ];

  return (
    <aside className="w-64 bg-surface shadow-lg border-r border-border fixed h-full overflow-y-auto">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <Shield className="text-white text-lg" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-foreground">DisasterOps</h1>
            <p className="text-xs text-muted-foreground">Response Platform</p>
          </div>
        </div>
      </div>

      {/* User Profile */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
            <User className="text-white text-sm" />
          </div>
          <div>
            <p className="text-sm font-medium text-foreground">netrunnerX</p>
            <p className="text-xs text-muted-foreground">Admin</p>
          </div>
          <div className="ml-auto">
            <span className="w-2 h-2 bg-secondary rounded-full block" title="Online"></span>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="p-4 space-y-2">
        {navItems.map((item) => (
          <a
            key={item.id}
            href={`#${item.id}`}
            className={`flex items-center space-x-3 px-3 py-2 rounded-lg font-medium transition-colors ${
              item.active
                ? 'bg-primary/10 text-primary'
                : 'hover:bg-muted text-muted-foreground hover:text-foreground'
            }`}
          >
            <item.icon className="w-5 h-5" />
            <span>{item.label}</span>
          </a>
        ))}
      </nav>

      {/* WebSocket Status */}
      <div className="absolute bottom-4 left-4 right-4">
        <div className="flex items-center space-x-2 text-xs text-muted-foreground bg-muted rounded-lg px-3 py-2">
          <div className={`w-2 h-2 rounded-full ${
            isConnected ? 'bg-secondary animate-pulse' : 'bg-destructive'
          }`}></div>
          <span>
            {connectionStatus === 'connected' ? 'Real-time Connected' : 
             connectionStatus === 'connecting' ? 'Connecting...' : 'Disconnected'}
          </span>
        </div>
      </div>
    </aside>
  );
}
