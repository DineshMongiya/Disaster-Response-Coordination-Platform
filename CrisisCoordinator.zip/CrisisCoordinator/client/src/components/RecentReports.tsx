import { useQuery } from "@tanstack/react-query";
import { ApiClient } from "@/lib/api";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Search, Eye, CheckCircle } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function RecentReports() {
  const { data: reports = [], isLoading } = useQuery({
    queryKey: ['/api/reports'],
    queryFn: () => ApiClient.getReports(),
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'verified': return 'secondary';
      case 'disputed': return 'destructive';
      default: return 'secondary';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'verified': return CheckCircle;
      case 'disputed': return Eye;
      default: return Search;
    }
  };

  if (isLoading) {
    return (
      <Card className="bg-surface shadow-sm border-border">
        <CardHeader>
          <h3 className="text-lg font-semibold text-foreground">Recent Reports & Verification</h3>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="animate-pulse flex items-start space-x-4 p-4 border border-border rounded-lg">
                <div className="w-16 h-16 bg-muted rounded-lg"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-muted rounded"></div>
                  <div className="h-4 bg-muted rounded w-3/4"></div>
                  <div className="h-12 bg-muted rounded"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-surface shadow-sm border-border">
      <CardHeader className="p-6 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-foreground">Recent Reports & Verification</h3>
          <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80">
            View All
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4">
          {reports.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No reports submitted yet
            </div>
          ) : (
            reports.slice(0, 3).map((report: any) => {
              const StatusIcon = getStatusIcon(report.verificationStatus);
              
              return (
                <div key={report.id} className="flex items-start space-x-4 p-4 border border-border rounded-lg">
                  <div className="w-16 h-16 bg-muted rounded-lg flex items-center justify-center flex-shrink-0">
                    {report.imageUrl ? (
                      <img 
                        src={report.imageUrl} 
                        alt="Report" 
                        className="w-full h-full object-cover rounded-lg" 
                      />
                    ) : (
                      <div className="text-muted-foreground">No Image</div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="text-sm font-medium text-foreground">
                          Report #{report.id}
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          Reported by {report.userId} • {formatDistanceToNow(new Date(report.createdAt), { addSuffix: true })}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant={getStatusColor(report.verificationStatus)} className="text-xs">
                          {report.verificationStatus}
                        </Badge>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-primary hover:text-primary/80 h-auto p-1"
                        >
                          <StatusIcon className="h-4 w-4 mr-1" />
                          {report.verificationStatus === 'verified' ? 'Verified' : 
                           report.verificationStatus === 'disputed' ? 'Review' : 'Verify'}
                        </Button>
                      </div>
                    </div>
                    <p className="text-sm text-foreground mt-2">{report.content}</p>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </CardContent>
    </Card>
  );
}
