# DisasterOps Emergency Response Platform

## Overview

DisasterOps is a real-time emergency response coordination platform built with a modern full-stack architecture. The application enables disaster management through real-time monitoring, resource coordination, social media integration, and collaborative reporting. It features a React-based dashboard for emergency coordinators and administrators to track active disasters, manage resources, verify reports, and coordinate response efforts.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized production builds
- **UI Framework**: Shadcn/UI components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens and dark mode support
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation
- **Real-time Updates**: WebSocket integration for live data updates

### Backend Architecture
- **Runtime**: Node.js with TypeScript
- **Framework**: Express.js for HTTP server and REST API
- **WebSocket**: Native WebSocket server for real-time communication
- **Database ORM**: Drizzle ORM with PostgreSQL support
- **Database Provider**: Neon serverless PostgreSQL
- **API Design**: RESTful API with structured error handling
- **Development**: TSX for TypeScript execution in development

### Build and Deployment
- **Development**: Concurrent client/server development with hot reloading
- **Production Build**: Vite builds client, esbuild bundles server
- **Deployment**: Autoscale deployment target on Replit infrastructure
- **Database Migrations**: Drizzle Kit for schema management

## Key Components

### Database Schema
The application uses a PostgreSQL database with the following core entities:
- **Users**: Authentication and role-based access (admin/contributor)
- **Disasters**: Central disaster tracking with geospatial data, tags, and audit trails
- **Reports**: User-submitted reports with verification status
- **Resources**: Location-based resource tracking (shelters, medical, food, supplies)
- **Cache**: Application-level caching for performance optimization

### API Architecture
- **Authentication**: Header-based user authentication with role checking
- **REST Endpoints**: CRUD operations for disasters, reports, and resources
- **Real-time Updates**: WebSocket broadcasts for live data synchronization
- **Mock Services**: Integrated mock APIs for AI analysis and external service simulation
- **Geospatial Queries**: Location-based resource discovery with radius search

### Frontend Components
- **Dashboard**: Main coordination interface with real-time statistics
- **Active Disasters List**: Live disaster tracking with priority indicators
- **Resource Map**: Geospatial resource visualization and management
- **Social Media Feed**: Integrated social monitoring with priority classification
- **Reports Verification**: Collaborative report validation system
- **Real-time Notifications**: WebSocket-powered live updates

## Data Flow

### Real-time Data Updates
1. Client establishes WebSocket connection on application load
2. Server broadcasts events (disaster_created, disaster_updated, social_media_updated)
3. React Query invalidates relevant cache entries automatically
4. UI components re-render with fresh data

### Disaster Management Flow
1. Admin creates disaster through modal form with location and tags
2. System geocodes location and stores geospatial coordinates
3. WebSocket notifies all connected clients of new disaster
4. Reports and resources can be associated with the disaster
5. Social media monitoring begins for related content

### Resource Coordination
1. Resources are created with precise geolocation data
2. Geospatial service calculates distances for proximity queries
3. Map interface displays resources with filtering by type
4. Real-time updates ensure resource availability accuracy

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18, React DOM, React Query for state management
- **UI Libraries**: Radix UI primitives, Lucide React icons, Tailwind CSS
- **Form Management**: React Hook Form with Hookform Resolvers
- **Database**: Drizzle ORM, Neon serverless PostgreSQL driver
- **Development Tools**: Vite, TSX, esbuild for build pipeline

### Utility Libraries
- **Date Handling**: date-fns for consistent date formatting
- **Validation**: Zod for schema validation and type safety
- **Styling**: class-variance-authority and clsx for dynamic styling
- **Geospatial**: Custom geospatial service using Haversine formula
- **WebSocket**: Native WebSocket for real-time communication

## Deployment Strategy

### Development Environment
- **Hot Reloading**: Vite dev server with React Fast Refresh
- **TypeScript**: Strict type checking across client and server
- **Database**: Local Neon PostgreSQL connection
- **Real-time**: WebSocket server integrated with Express

### Production Deployment
- **Build Process**: Client builds to static assets, server bundles with esbuild
- **Database**: Production Neon PostgreSQL with connection pooling
- **Scaling**: Autoscale deployment on Replit infrastructure
- **Static Assets**: Served through Express with production optimizations

### Configuration Management
- **Environment Variables**: DATABASE_URL for PostgreSQL connection
- **TypeScript Paths**: Shared types and utilities across client/server
- **Development Tools**: Replit-specific plugins for enhanced development experience

## Changelog

```
Changelog:
- June 18, 2025. Initial setup
- June 18, 2025. Completed disaster response coordination platform with:
  * Full CRUD API for disasters, reports, and resources
  * Real-time WebSocket integration
  * Mock external service integrations (Gemini AI, geocoding, social media)
  * Dashboard with statistics, active disasters, and resource mapping
  * Authentication system with hardcoded users
  * Caching system for API responses
  * Sample data initialization for demonstration
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```